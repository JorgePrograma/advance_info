import {
  Directive,
  Input,
  TemplateRef,
  ViewContainerRef,
  effect,
  inject,
  signal
} from '@angular/core';
import { PermissionService } from '../services/permission.service';

@Directive({
  selector: '[appHasPermission]',
  standalone: true,
})
export class HasPermissionDirective {
  // 1. Usar signal para el input
  private actionId = signal<string>('');
  private hasView = false;

  // 2. Inyectar dependencias
  private templateRef = inject(TemplateRef<any>);
  private viewContainer = inject(ViewContainerRef);
  private permissionService = inject(PermissionService);

  // 3. Configurar effect reactivo
  private permissionEffect = effect(() => {
    const hasPermission = this.permissionService.hasPermission(this.actionId());
    this.updateView(hasPermission);
  });

  // 4. Input simplificado solo para actionId
  @Input({ required: true }) set appHasPermission(id: string) {
    this.actionId.set(id);
  }

  // 5. Método optimizado para actualizar vista
  private updateView(hasPermission: boolean) {
    if (hasPermission && !this.hasView) {
      this.viewContainer.createEmbeddedView(this.templateRef);
      this.hasView = true;
    } else if (!hasPermission && this.hasView) {
      this.viewContainer.clear();
      this.hasView = false;
    }
  }
}
