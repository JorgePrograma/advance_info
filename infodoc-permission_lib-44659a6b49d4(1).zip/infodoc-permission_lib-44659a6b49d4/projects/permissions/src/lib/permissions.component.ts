import { Component } from '@angular/core';

@Component({
  selector: 'sgdea-permissions',
  imports: [],
  template: `
    <p>
      permissions works!
    </p>
  `,
  styles: ``
})
export class PermissionsComponent {

}
