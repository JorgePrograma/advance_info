import { computed, Injectable, signal } from '@angular/core';
import { Aplications } from '../model/permission.model';

@Injectable({ providedIn: 'root' })
export class PermissionService {
  // Almacenar los permisos en una Signal
  private readonly _permissions = signal<Aplications | null>(null);

  // Convertir la estructura jerárquica a un Set plano de actionIds
  private readonly actionIds = computed(() => {
    const permissions = this._permissions();
    if (!permissions) return new Set<string>();

    const ids = new Set<string>();
    permissions.permissionsapplication.forEach(app =>
      app.modules.forEach(module =>
        module.subModules.forEach(subModule =>
          subModule.actions.forEach(action =>
            ids.add(action.idAction)
          )
        )
      )
    );
    return ids;
  });

  setPermissions(permissions: Aplications): void {
    this._permissions.set(permissions);
  }

  hasPermission(actionId: string): boolean {
    return this.actionIds().has(actionId);
  }

  // Nueva funcionalidad para múltiples permisos
  hasAnyPermission(actionIds: string[]): boolean {
    const currentIds = this.actionIds();
    return actionIds.some(id => currentIds.has(id));
  }

  // Versión reactiva
  hasPermissionSignal = (actionId: string) => {
    return computed(() => this.actionIds().has(actionId));
  }
}
