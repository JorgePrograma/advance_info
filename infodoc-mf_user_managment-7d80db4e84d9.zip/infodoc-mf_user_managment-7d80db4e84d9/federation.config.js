const { withNativeFederation, share } = require('@angular-architects/native-federation/config');

module.exports = withNativeFederation({
  name: 'mfe-user-management',

  exposes: {
    './Component': './src/app/app.component.ts',
    './routes': './src/app/app.routes.ts',
  },

  shared: {
    ...share({
      '@angular/core': {
        singleton: true,
        strictVersion: true,
        requiredVersion: 'auto' // Webpack determinará automáticamente la versión
      },
      '@angular/common': {
        singleton: true,
        strictVersion: true,
        requiredVersion: 'auto', // Webpack determinará automáticamente la versión
        includeSecondaries: true // Esto incluye submódulos como rxjs/operators
      },
      '@angular/router': {
        singleton: true,
        strictVersion: true,
        requiredVersion: 'auto' // Automático para Angular
      },
      'rxjs': {
        singleton: true,
        strictVersion: true,
        requiredVersion: 'auto', // Automático para RxJS
        includeSecondaries: true // Esto incluye submódulos como rxjs/operators
      },
    }
  ),
  },

  skip: [
    'rxjs/ajax',
    'rxjs/fetch',
    'rxjs/testing',
    'rxjs/webSocket',
    // Add further packages you don't need at runtime
  ]

  // Please read our FAQ about sharing libs:
  // https://shorturl.at/jmzH0

});
