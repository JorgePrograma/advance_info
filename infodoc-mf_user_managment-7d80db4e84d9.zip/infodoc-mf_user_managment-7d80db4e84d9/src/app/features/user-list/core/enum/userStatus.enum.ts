export enum UserStatusEnum {
  ACTIVE = 'activar',
  INACTIVE = 'desactivar',
  BLOCKED = 'bloquear',
  SUSPEND = 'suspender',
}
