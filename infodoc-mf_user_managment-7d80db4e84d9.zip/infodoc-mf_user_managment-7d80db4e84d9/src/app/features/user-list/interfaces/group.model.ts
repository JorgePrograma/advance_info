export interface GroupModel{
  id:string,
  name:string,
}
