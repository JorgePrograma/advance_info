export type SignatureType = 'digital' | 'rubrica'; 
