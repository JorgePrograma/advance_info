export interface CanvasConfig {
  width?: number;
  height?: number;
  lineWidth?: number;
  strokeStyle?: string;
  fillStyle?: string;
}
