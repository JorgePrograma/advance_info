export interface DocumentTypeModel{
  id: string,
  name:string,
  prefix:string
}
