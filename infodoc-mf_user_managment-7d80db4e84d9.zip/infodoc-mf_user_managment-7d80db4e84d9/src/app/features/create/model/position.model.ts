export interface PositionModel {
  id: string;
  code: string;
  name: string;
  description: string;
  isActive: boolean;
}
