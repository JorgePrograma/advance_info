export interface EmployeeInfoModel {
  idPerson: string;
  bussinesEmail: string;
  bussinesPhone?: string;
  idPosition?: string| null;
  idBranch?: string;
  idUser?:string
  id:string;
}
