export interface ContactInfoModel{
  id:string;
  idPerson:string,
  email:string,
  phoneNumber:string,
  address:string
}
