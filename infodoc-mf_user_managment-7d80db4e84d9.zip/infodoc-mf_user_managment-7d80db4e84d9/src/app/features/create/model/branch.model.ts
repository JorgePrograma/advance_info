export interface BranchModel{
  id:string,
  name:String
}
