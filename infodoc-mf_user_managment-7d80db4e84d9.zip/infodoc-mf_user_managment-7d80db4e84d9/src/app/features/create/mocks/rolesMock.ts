import { Role } from "../model/role.model";

export class RolesMock {
  public static rolesMock: Role[] = [
   
  ];
}
