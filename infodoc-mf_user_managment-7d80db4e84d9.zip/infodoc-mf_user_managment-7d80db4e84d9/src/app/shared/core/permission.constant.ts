export class PermissionConstant {
  static readonly CREATE_USER = '0d6f2c96-7cff-46b8-9d88-71d5900b8a64';
  static readonly UPDATE_USER = '';
  static readonly UPDATE_SIGNATURE = 'b9931710-59a1-486f-972c-829ab71429ff';
  static readonly ACTIVE_OR_DESACTIVE_USER ="ffe937d8-f5ca-4c2d-a040-059abe0c2be6"
  static readonly BLOCKED_USER ="8ae38222-1bdc-4442-9e03-c6d3ea7e7970"
  static readonly SUSPEND_USER ="04927286-0652-48f6-91c2-12b290efdaad"
  static readonly LISTAR_USER = 'd30460c0-5ae0-47ce-9a3b-ff53c4a34f13';
  static readonly APPLICATION_ID = 'dde09479-7e15-4d72-b73d-2fd703a143fe';
}
