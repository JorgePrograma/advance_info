export interface Contact {
  id: string;
  idPerson: string;
  email: string;
  phoneNumber: string;
  address: string;
}
