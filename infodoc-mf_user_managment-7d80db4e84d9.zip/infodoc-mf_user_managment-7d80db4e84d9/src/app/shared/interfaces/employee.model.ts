export interface Employee {
  id: string;
  idPerson: string;
  idUser: string; // id de usuario
  bussinesEmail: string;
  bussinesPhone: string;
  idPosition: string | null;
  idBranch: string | null;
}
