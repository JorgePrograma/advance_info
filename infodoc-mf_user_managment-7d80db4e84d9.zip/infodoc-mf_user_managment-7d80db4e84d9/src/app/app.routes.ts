import { Routes } from '@angular/router';
import { UserRegistrationComponent } from './features/create/component/user-registration/user-registration.component';
import { UserTableComponent } from './features/user-list/component/user-table/user-table.component';
import { CreateComponent } from './features/signatures/component/create/create.component';
import { ComponentComponent } from './features/permission/component/component.component';

export const APP_ROUTES: Routes = [
  { path: 'create', component: UserRegistrationComponent },
  { path: 'firmas', component: CreateComponent },
  { path: 'list', component: UserTableComponent },
  { path: 'editar/:id', component: UserRegistrationComponent },
  { path: 'test', component: ComponentComponent },
  { path: '', redirectTo: 'create', pathMatch: 'full' },
];
