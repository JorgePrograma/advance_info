export const environment = {
    production: false,
    apiUrl: 'https://femrwzf6x6uakaqkb32tl27hgm.apigateway.sa-bogota-1.oci.customer-oci.com',
    featureFlag: false
  };