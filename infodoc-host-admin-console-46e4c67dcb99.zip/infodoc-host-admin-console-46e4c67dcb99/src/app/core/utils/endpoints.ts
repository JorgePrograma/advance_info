export class EndPoints {
  static readonly base_url =
    'https://nwkd5nddy5o7pliwwu7exacllq.apigateway.sa-bogota-1.oci.customer-oci.com/api/v1';
  static readonly USERS = this.base_url + '/user/get-by-filter';
}
