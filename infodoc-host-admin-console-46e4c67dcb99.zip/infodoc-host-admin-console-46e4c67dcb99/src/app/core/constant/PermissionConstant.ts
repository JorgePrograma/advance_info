import { Permission } from './../../interfaces/Permissions';
export class PermissionConstant {
  static readonly APPLICATION_ID = 'dde09479-7e15-4d72-b73d-2fd703a143fe';
  
}
