/** @type {import('tailwindcss').Config} */
module.exports = {
  important: true,
  content: [
    "./src/**/*.{html,ts}",
  ],
  safelist: [
    // ✅ Layout
    'w-full',
    'max-w-[90%]',
    'min-h-screen',
    'overflow-x-auto',
    'rounded',
    'rounded-md',
    'rounded-b-md',
    'rounded-t-md',
    'rounded-lg',
    'rounded-full',
    'shadow-md',
    'border',
    'border-gray-300',
    'border-t-0',

    // ✅ Spacing
    'p-0',
    'p-4',
    'p-6',
    'p-8',
    'px-2',
    'px-4',
    'py-1',
    'py-3',
    'py-4',
    'mt-2',
    'mt-4',
    'mt-6',
    'mb-1',
    'mb-2',
    'mb-4',
    'mb-8',
    'ml-2',
    'ml-4',
    'mr-2',
    'pl-4',
    'pt-1',

    // ✅ Grid / Flex
    'flex',
    'flex-wrap',
    'items-center',
    'items-end',
    'justify-center',
    'justify-end',
    'justify-between',
    'space-x-2',
    'space-y-1',
    'gap-3',
    'gap-4',
    'gap-6',
    'grid',
    'grid-cols-1',
    'grid-cols-2',
    'md:grid-cols-2',
    'md:grid-cols-3',
    'col-span-2',

    // ✅ Typography
    'text-center',
    'text-left',
    'text-sm',
    'text-base',
    'text-lg',
    'text-xl',
    'text-2xl',
    'text-3xl',
    'text-white',
    'text-gray-700',
    'text-blue-800',
    'text-red-800',
    'font-medium',
    'font-semibold',
    'font-bold',

    // ✅ Background
    'bg-white',
    'bg-gray-100',
    'bg-gray-50',
    'bg-red-800',

    // ✅ Icon Sizes
    'w-6',
    'h-6',

    // ✅ Transitions
    'transition',
    'duration-300',
    'duration-500',

    // ✅ Responsive
    'md:w-1/2',
    'md:w-full',

    // ✅ Otros
    'cursor-pointer',
    'select-none',
    'hidden',
    'mat-icon-button',

    // ✅ Regex helpers (Tailwind v3+)
    { pattern: /^w-/ },
    { pattern: /^h-/ },
    { pattern: /^mb-/ },
    { pattern: /^mr-/ },
    { pattern: /^mt-/ },
    { pattern: /^ml-/ },
    { pattern: /^p-/ },
    { pattern: /^px-/ },
    { pattern: /^py-/ },
    { pattern: /^mx-/ },
    { pattern: /^m[trbl]?-/ },
    { pattern: /^max-/ },
    { pattern: /^text-/ },
    { pattern: /^leading-/ },
    { pattern: /^tracking-/ },
    { pattern: /^gap-/ },
    { pattern: /^rounded/ },
    { pattern: /^shadow-/ },
    { pattern: /^font-/ },
    { pattern: /^bg-/ },
    { pattern: /^justify-/ },
    { pattern: /^items-/ },
    { pattern: /^flex-/ },
    { pattern: /^grid-/ },
    { pattern: /^grid-cols-/ },
    { pattern: /^space-x-/ }
  ],
  theme: {
    extend: {},
  },
  plugins: [],
  corePlugins: {
    preflight: false, // Desactiva el reset global de Tailwind
  },
};
